<div class="pl-2 pr-3 fs--1">
   <div class="d-flex bd-highlight">
      <div class=" flex-grow-1 bd-highlight">
         <div class="float-right">
            <a class="btn theme-color shadow-sm border fs--1 bg-white text-muted" onclick="$('#user_no_account_message_modal').modal('show');"  data-target="#job_make_offer" style="border-radius:20px;" href="#" role="button"  aria-haspopup="true" aria-expanded="false">
             Send Offer 
            </a>
         </div>
      </div>
   </div>
   <div class="" id="service_provider_list_view" style="overflow:scroll; height:600px;scroll-behavior: smooth;">
      <div class="text-center p-3">
         <img src="{{asset('images/svg/sp_messages_2.svg')}}" alt="" style="opacity:0.4;" class="img-fluid" alt="Responsive image">
         <br>
         <br>
         <span>You can send you price quote by clicking below.</span>
         <br><br>
         <a class="btn theme-color shadow-sm border fs--1 bg-white text-muted" onclick="$('#user_no_account_message_modal').modal('show');"  data-target="#job_make_offer" style="border-radius:20px;" href="#" role="button"  aria-haspopup="true" aria-expanded="false">
            Send Offer
         </a>
      </div>
   </div>
</div>