<?php $__env->startSection('content'); ?>
<div class="container " style="margin-bottom:40%;">
   <div class="row  justify-content-center" >
      <div class="col-lg-12 mt-2 p-0" > 
         <?php echo $__env->make('service_provider.profile.nested.service_provider_profile_partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
   </div>
</div>
<!-- end service selector -->
<?php echo $__env->make('service_provider.bottom_navigation_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.service_provider_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/profile/nested/index.blade.php ENDPATH**/ ?>