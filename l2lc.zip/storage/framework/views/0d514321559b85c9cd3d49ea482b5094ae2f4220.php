<?php $__env->startComponent('mail::message' ); ?>
# Hi there!

<p>The status of the job with id <?php echo e($job->id); ?> has been changed to "<?php echo e($job->status); ?>". Please navigate to LocaL2LocaL app to know more.</p>

<?php $__env->startComponent('mail::table'); ?>
| Job ID       | Job Title         | Status  |
| ------------- |:-------------:| --------:|
| <?php echo e($job->id); ?>     |  <?php echo e($job->service_category_name); ?> - <?php echo e($job->service_subcategory_name); ?>      |  <?php echo e($job->status); ?>      |
<?php echo $__env->renderComponent(); ?>


<?php $__env->startComponent('mail::button', ['url' => url('/').'/service_seeker/jobs/job/'.$job->id]); ?>
View Job
<?php echo $__env->renderComponent(); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\l2lc\resources\views/mail/job/status_update.blade.php ENDPATH**/ ?>