<div class="fs--1">
   <div class="mt-3 border-0  rounded shadow-sm-none" >
      <div class="d-flex bd-highlight">
         <div class="p-q bd-highlight">
            <span class="theme-color" style="font-size: 0.8rem;">Job Total</span>  <br>
            <span class="text-success fs-1">$<?php echo e($conversation->json['offer']); ?></span>
         </div>
         <div class="ml-auto p-2 bd-highlight">
            <a href="<?php echo e(route('service_provider_job_conversation', [$conversation->job_id, $conversation->service_provider_id])); ?>" class="btn btn-sm theme-background-color text-white card-1 fs--1" onclick="toggle_animation(true);"><i class="fas fa-comments-dollar"></i> Messages</a>
         </div>
      </div>
   </div>
   <div class="text-center p-3">
      <img src="<?php echo e(asset('images/svg/l2l_vault.svg')); ?>" alt="" style="opacity:0.4;"  width="150px" class="img-fluid" alt="Responsive image">
      <br>
      <br>
      <p class="fs--1">Please enter the pin code in the input field given below. Please ask for PIN code from Service Seeker.</p>
      <form action="<?php echo e(route('service_provider_job_update_status_mark_started')); ?>" class="text-center" method="POST" onsubmit="toggle_animation(true);">
         <?php echo csrf_field(); ?>
         <!-- <label for="pin_code_input">Enter PIN Code Below</label> -->
         <input type="hidden" value="<?php echo e($job->id); ?>" name="job_id" required>
         <input type="text" name="pin_code_input"
         maxlength="4" minlength="4"
         onkeypress='return event.charCode >= 48 && event.charCode <= 57'    
         required  placeholder="----" style="text-align:center;"  class="form-control form-control-lg-b rounded-0 <?php if ($errors->has('pin_code_input')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pin_code_input'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"> 
         <?php if ($errors->has('pin_code_input')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pin_code_input'); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
            </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
         <br> <br>
         <button class="btn btn-sm theme-background-color border-0 card-1  fs--1 text-white  delay-2s mr-2" type="submit">Start Job <i class="fas fa-arrow-right fs--2"></i></button>
      </form>
   </div>
</div><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/jobs/partial/job_overview_partial_arrived.blade.php ENDPATH**/ ?>