
<div class="row m-2">
   <div class="col-12 fs--1 p-2 ">
     <form method="POST" action="<?php echo e(route('app_user_update_password_information')); ?>" onsubmit="toggle_animation(true);">
      <?php echo csrf_field(); ?>
      <div class="form-group">
         <label for="exampleInputEmail1">Password</label>
         <input type="password" class="form-control form-control-sm <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> border border-danger is-invald  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  id="password_input" name="password" autocomplete="off">
         <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
         <span class="invalid-feedback text-danger" style="display:block;" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="form-group">
         <label for="exampleInputEmail1">Confirm Password</label>
         <input type="password" class="form-control form-control-sm"  id="password_confirm" name="password_confirmation" value="">
      </div>
      <div class="form-group">
         <button class="btn theme-background-color text-white btn-sm fs--1 font-weight-normal card-1">Save Changes</button>
      </div>
    </form>
   </div>
</div>
<?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/profile/password.blade.php ENDPATH**/ ?>