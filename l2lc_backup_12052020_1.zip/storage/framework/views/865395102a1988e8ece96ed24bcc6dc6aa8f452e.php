<?php $__env->startSection('content'); ?>
<div class="container ">
   <div class="row  justify-content-center" >
      <div class="col-lg-12 sticky-top shadow-sm bg-white p-3  border-d">
      <div class="row">
            <div class="col-4">  <a href="<?php echo e(route('service_seeker_jobs')); ?>" onclick="toggle_animation(true);"><i class="fas fa-arrow-left theme-color fs-1" ></i> </a> </div>
            <div class="col-4 font-size-bolder text-center font-weight-bold theme-color">Job History <br><span class="fs--2 text-muted font-weight-normal">Full History</span></div>
            <div class="col-4 text-right"></div>
         </div>
      </div>
      <div class="col-lg-12 pl-2 pr-2 mt-2 border-d">
         <ul class="list-group fs--1" style="overflow:scroll; height:640px;">
           <?php $__currentLoopData = $service_seeker_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item mt-2 mb-2 ml-2 mr-2 card-1 border-0" onclick="location.href= app_url + '/service_seeker/jobs/job/<?php echo e($job->id); ?>';toggle_animation(true);" style="cursor:pointer;">
               <div class="d-flex bd-highlight">
                  <div class="pb-2 w-100 bd-highlight theme-color font-weight-bold" style="font-size: 0.9rem;"><?php echo e(ucfirst($job->title)); ?></div>
               </div>
               <div class="d-flex bd-highlight">
                  <div class="p-0 w-100 bd-highlight"><i class="fas fa-map-marker-alt"></i> <?php echo e($job->city); ?>, <?php echo e($job->postcode); ?></div>
                  <div class="p-0 flex-shrink-1 bd-highlight text-secondary">
                     <?php if($job->status == 'APPROVED'): ?>
                        <span class="badge  badge-success  p-2 fs--2 font-weight-normal animated rubberBand delay-1s" style="border-radius:20px!important;">Approved</span>
                     <?php elseif($job->status == 'ONTRIP'): ?>
                        <span class="badge  badge-warning  p-2 fs--2 font-weight-normal animated rubberBand delay-1s " style="border-radius:20px!important;">On-Trip</span>
                     <?php elseif($job->status == 'ARRIVED'): ?>
                        <span class="badge  badge-secondary  p-2 fs--2 font-weight-normal animated rubberBand delay-1s" style="border-radius:20px!important;">Arrived</span>
                     <?php elseif($job->status == 'STARTED'): ?>
                        <span class="badge  badge-warning  p-2 fs--2 font-weight-normal animated rubberBand delay-1s" style="border-radius:20px!important;">In-Progress</span>
                     <?php elseif($job->status == 'COMPLETED'): ?>
                        <span class="badge  badge-secondary  p-2 fs--2 font-weight-normal" style="border-radius:20px!important;">Completed</span>
                     <?php elseif($job->status == 'CANCELLED'): ?>
                     <span class="badge  badge-danger  p-2 fs--2 font-weight-normal" style="border-radius:20px!important;">Cancelled</span>
                     <?php endif; ?> 
                  </div>
               </div>
               <div class="d-flex bd-highlight">
                  <div class="p-0 w-100 bd-highlight"><i class="far fa-calendar-alt"></i> <?php echo e(date('d/m/Y h:i a', strtotime($job->job_date_time))); ?></div>
               </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($service_seeker_jobs) == 0): ?> 
            <div class="text-center p-3">
               <img src="<?php echo e(asset('images/svg/l2l_ss_no_data.svg')); ?>" alt="" style="opacity:0.4;"  class="img-fluid" alt="Responsive image">
               <br>
               <br>
               <span>Oh no! It seems all empty here. You do not have any completed jobs.</span>
               <br><br>
            </div>
            <?php endif; ?>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.service_seeker_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/jobs/full_history.blade.php ENDPATH**/ ?>