<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="list-group-item m-1 card-1 border-0 fs--2"  style="cursor:pointer;" onclick="location.href= app_url + '/service_provider/jobs/job/<?php echo e($job->id); ?>';toggle_animation(true);">
    <div class="d-flex bd-highlight">
        <div class="pb-2 w-100 bd-highlight theme-color font-weight-bold" style="font-size: 0.9rem;"><?php echo e($job->title); ?></div>
    </div>
    <div class="d-flex bd-highlight">
        <div class="p-0 w-100 bd-highlight"><i class="fas fa-map-marker-alt mr-1"></i><?php echo e($job->suburb); ?> <?php echo e($job->city); ?> <?php echo e($job->postcode); ?></div>
        <div class="p-0 flex-shrink-1 bd-highlight text-secondary">
            <span class="badge bg-white theme-color  p-2 fs--2 font-weight-normal animated zoomIn card-1 font-weight-bolder" style="border-radius:20px!important;"><?php echo e(number_format($job->distance,2)); ?> kms</span>
        </div>
    </div>
    <div class="d-flex bd-highlight">
        <div class="p-0 w-100 bd-highlight"><i class="far fa-calendar-alt"></i> <?php echo e(date('d/m/Y h:i a', strtotime($job->job_date_time))); ?></div>
    </div>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(count($jobs) == 0): ?> 
<div class="text-center p-3 fs--1">
      <!-- <img src="<?php echo e(asset('images/svg/l2l_empty.svg')); ?>" alt="" style="opacity:0.4;width:200px"  class="img-fluid" alt="Responsive image"> -->
      <i class="fas fa-circle-notch fs-2 theme-color fa-spin"></i>
      <br>
      <br>
      <span>We are still looking for Job that matches your profile. Please stay tuned..</span>
      <br><br>
  </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/jobs/jobs_templates/jobs_homepgae_template_list.blade.php ENDPATH**/ ?>