<?php $__env->startSection('content'); ?>
<?php $__env->startPush('header-script'); ?>
<script src="<?php echo e(asset('/js/service_seeker/service_seeker_home_starter_map.js')); ?>?v=<?php echo e(rand(1,100)); ?>"></script>
<?php $__env->stopPush(); ?>

<!-- page specific styles -->
<style>
   #map {
   position: relative;
   width: 100%;
   height: 90%;
   background: #eee;
   }
   #wrapper { position: relative; }
   #over_map_bottom { position: absolute; bottom: 10%; left: 0px; z-index: 99;min-width:100%;padding:10px; }
   #over_map_top { position: absolute; top: 2%; left: 0px; z-index: 99;min-width:100%;padding:10px; }
   .modal-backdrop {
   position: fixed;
   top: 0;
   right: 0;
   bottom: 0;
   left: 0;
   z-index: 10;
   background-color:transparent!important;
   }
   .pac-container {
   background-color: #FFF;
   z-index: 20;
   position: fixed;
   display: inline-block;
   float: left;
   }
   .modal{
   z-index: 20;   
   }
</style>
<!-- end style  -->
<div class="wrapper">
   <div id="map"  style="min-width:100%!important;"></div>
   <div id="over_map_bottom" class="text-center">
      <span id="user_current_saved_location" class="bg-white p-1 fs--1" style="border-radius:20px;"><?php echo e(Auth::user()->user_full_address); ?></span><br>
      <a class="btn btn-block btn-sm theme-background-color card-1  mt-2" style="border-radius:20px;" href="<?php echo e(route('service_seeker_home')); ?>?showBooking=on" onclick="toggle_animation(true);">I want work done</a>
      <a class="btn btn-block btn-sm text-white mt-2 card-1" style="border-radius:20px;background:#5D29BA!important;color:white!important;" href="<?php echo e(route('service_provider_home')); ?>" onclick="toggle_animation(true);">Switch to Provider - I want to done</a>
   </div>
   <div id="over_map_top" >
      <?php if(count($jobs) > 0): ?>
         <div class="bg-white fs--1 card-1 theme-color p-3" style="border-radius:20px;">
            <a href="<?php echo e(route('service_seeker_jobs')); ?>" class="text-decoration-none theme-color" onclick="toggle_animation(true);">You currently have jobs pending on your job board. Tap here to go to jobs tab <i class="fas fa-arrow-right"></i></a> 
         </div>
      <?php endif; ?>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="user_location_modal_manual_popup" tabindex="-1" role="dialog" aria-labelledby="user_location_modal_manual_popup_title" aria-hidden="true">
   <div class="modal-dialog modal-dialog-centereds" role="document">
      <div class="modal-content border-0 card-1">
         <div class="modal-body text-center" style="min-height:300px;">
            <!-- <i class="fas fa-exclamation-triangle display-1 text-danger"></i> -->
            <br><br>
            <p>Unable to update location automatically, please type in your address below.</p>
            <input type="text" class="form form-control" id="user_location_modal_manual_popup_input" onFocus="initAutocomplete()"/>
            <br>
            <button class="btn btn-danger text-white" style="border-radius:30px;" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>
<!-- end modal -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyClfjwR-ajvv7LrNOgMRe4tOHZXmcjFjaU&libraries=places&callback=initMap" async defer></script>
<!-- script to control the map function -->
<script>
var app_url = "<?php echo e(URL::to('/')); ?>";
var current_suburb = "<?php echo e(Auth::user()->user_city); ?>";
var current_lat = "<?php echo e(Auth::user()->user_lat); ?>";
var current_lng = "<?php echo e(Auth::user()->user_lng); ?>";
//user service provider location update url to update user current address
var seeker_update_current_location = "<?php echo e(route('service_seeker_services_location_update')); ?>";
var update_location_on_load = false;

window.onload = function() {
   if(current_lat == '' || update_location_on_load) {
      update_user_location();
   }
}
</script>
<!-- end map control script  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('service_seeker.bottom_navigation_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.service_seeker_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/service_seeker_home_1.blade.php ENDPATH**/ ?>