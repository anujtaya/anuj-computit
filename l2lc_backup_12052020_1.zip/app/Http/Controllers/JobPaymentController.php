<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JobPaymentController extends Controller
{
    //
}
