<div class="p-0">
   <?php if(Session::has('status')): ?>
   <div class="alert alert-success fs--1" role="alert">
      <?php echo e(Session::pull('status')); ?>

   </div>
   <?php endif; ?>
   <?php if(Session::has('error')): ?>
   <div class="alert alert-error fs--1" role="alert">
      <?php echo e(Session::pull('error')); ?>

   </div>
   <?php endif; ?> 
   <!-- notice section display -->
   <div class="fs--2 p-2 alert alert-warning border-0 card-1">
      Please note that the details of this job can only be changed when the job status is Open.
      Once the job is approved you will not be able to change the details of the job.
      You will need to cancel the job if you wish to change the detail of the job once its approved.
   </div>
   <!-- end notice section display -->
   <form action="<?php echo e(route('service_seeker_job_details_update')); ?>" method="post" onsubmit="toggle_animation(true);">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="update_job_id" value="<?php echo e($job->id); ?>">
      <div class="form-group">
         <label  class="font-weight-bold" for="exampleInputEmail1">Location</label> <br>
         <?php echo e($job->street_number); ?> <?php echo e($job->street_name); ?> <br>
         <?php echo e($job->city); ?><br><?php echo e($job->state); ?>, <?php echo e($job->postcode); ?>

      </div>
      <div class="form-group">
         <label class="font-weight-bold" for="job_scheduled_for">Job Schedule Time</label>
         <br>
         <?php echo e(date('d/m/Y h:ia', strtotime($job->job_date_time))); ?>

      </div>
      <?php if($job->status == 'OPEN'): ?>
         <div class="form-group">
            <label class="font-weight-bold" for="update_job_datetime">Change Schedule Time</label>
            <input type='datetime-local' class="form-control form-control-sm"  id="update_job_datetime" name="update_job_datetime" value="<?php echo e(\Carbon\Carbon::parse($job->job_date_time)->format('Y-m-d\TH:i:s')); ?>">
         </div>
      <?php endif; ?>
      <div class="form-group">
         <label  class="font-weight-bold" for="update_job_title">Job Title</label> <br>
         <input name="update_job_title" class="form-control form-control-sm" value="<?php echo e($job->title); ?>">

      </div>
      <div class="form-group">
         <label class="font-weight-bold" for="update_job_description">Description</label> <br>
         <textarea name="update_job_description" class="form-control form-control-sm" id="update_job_description"  rows="2"><?php echo e($job->description); ?></textarea>
      </div>
      <div class="form-group">
         <?php if($job->status != 'COMPLETED'): ?>
            <?php if($job->status != 'CANCELLED'): ?>
               <button class="btn btn-info btn-sm fs--1 font-weight-normal" type="submit">Save Changes</button>
            <?php endif; ?>
         <?php endif; ?>
      </div>
   </form>
   <!-- <div class="fixed-bottom p-2 fs--1 text-center bg-white border-top">Scroll for more <i class="fas fa-angle-double-down fs--2 mt-1"></i></div> -->
</div>
<?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/jobs/job_description_partial.blade.php ENDPATH**/ ?>