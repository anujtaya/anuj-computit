<?php $__env->startSection('content'); ?>
<div class="container ">
   <div class="row  justify-content-center" >
      <div class="col-lg-12 shadow-sm sticky-top bg-white p-3 border-d">
         <div class="row">
            <div class="col-4">   <a href="<?php echo e(route('service_provider_more')); ?>" onclick="toggle_animation(true);">  <i class="fas theme-color fa-arrow-left fs-1"></i></a> </div>
            <div class="col-4 font-size-bolder text-center font-weight-bold theme-color">Help <br><span class="fs--2 text-muted font-weight-normal">Help & Support</span></div>
         </div>
      </div>
      <div class="col-lg-12  bg-white p-3 mt-2  border-d">
         <?php if(Session::has('status')): ?>
            <div class="alert alert-info fs--1">
               <?php echo e(Session::pull('status')); ?>

            </div>   
         <?php endif; ?>
         <form action="<?php echo e(route('app_services_support_send_support_email')); ?>" method="POST" onsubmit="toggle_animation(true);">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
               <label for="support_type" class="col-md-4 col-form-label fs--1 text-md-right">Select  help type</label>
               <div class="col-md-8">
                  <select  class="form-control form-control-sm <?php if ($errors->has('support_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('support_type'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="support_type" id="support_type" required>
                     <option value="General Help">General Help</option>
                     <option value="Job Help">Job Help</option>
                     <option value="Feedback">Feedback</option>
                     <option value="Payment Help">Payment Help</option>
                     <option value="Category Suggestions">Category Suggestions</option>
                     <option value="Other">Other</option>
                  </select>
               </div>
            </div>
            <div class="form-group row">
               <label for="support_message" class="col-md-4 col-form-label fs--1 text-md-right">Write your message below</label>
               <div class="col-md-8">
                  <textarea class="form-control form-control-sm <?php if ($errors->has('support_message')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('support_message'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="support_message" id="support_message" cols="30" rows="10" required placeholder="Please type in your comments here.."></textarea>
                  <?php if ($errors->has('support_message')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('support_message'); ?>
                  <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
               </div>
            </div>
            <div class="form-group pl-3 pt-2 row">
               <button class="btn theme-background-color btn-sm fs--1">Submit </button>
            </div>
         </form>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.service_provider_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/more/help.blade.php ENDPATH**/ ?>