<?php $__env->startSection('content'); ?>
<?php $__env->startPush('header-style'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header-script'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>
<div class="container mt-2">
   <div class="row  justify-content-center" >
      <div class="col-lg-4  ">
         <div class="row   " >
            <div class="col-md-12 h-100  " >
               <div class="card bg-white p-3 shadow-none">
                  <div class="d-flex bd-highlight mb-1">
                     <div class="p-1 theme-color bd-highlight">  
                        <span class="fs--">Step 4 of 4</span> 
                     </div>
                     <div class="p-1 ml-auto bd-highlight">
                        <a href="<?php echo e(route('service_provider_register_completed')); ?>"  class="font-weight-bolder theme-color" onclick="toggle_animation(true);"> Finish</a>
                     </div>
                  </div> 
                  <div class="mt-2 text-centers">
                     <h1 class="fs-1">Select your language skills</h1>
                  </div>

                  <div class="p-1">
                     <?php echo $__env->make('service_provider.language.add_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <div class=" mb-2 text-centers">
                        <h1 class="fs-1">Saved Languages</h1>
                     </div>
                     <ul class="list-group fs--1">
                        <?php $__currentLoopData = $current_languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">               
                           <div class="d-flex bd-highlight">
                              <div class="p-1 flex-grow-1 bd-highlight"> <?php echo e($language->language_name); ?></div>
                              <div class="p-1 bd-highlight"> <a href="<?php echo e(route('service_provider_delete_language', $language->id)); ?>" onclick="toggle_animation(true);" class="text-decoration-none text-danger">Remove</a> </div>
                           </div>      
                        </li>   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>         
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="progress fixed-top rounded-0" style="height: 10px;">
  <div class="progress-bar  theme-background-color" role="progressbar" style="width:80%;" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<script>
    $(".progress-bar").animate({
    width: "95%"
}, 100);

$(document).ready(function() { $("#language-select").select2(); });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.service_provider_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/language/language_registration_page.blade.php ENDPATH**/ ?>