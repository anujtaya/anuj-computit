<div class="fs--1">
   <div class="text-center p-3">
      <img src="<?php echo e(asset('images/svg/l2l_delete.svg')); ?>" alt="" style="opacity:0.4;"  width="250px" class="img-fluid" alt="Responsive image">
      <br><br>
      <p>
         No more action needed. This job is safely marked as cancelled. Detail of callation fee charge will appear below if applicable.
      </p>
      <p>
         If you have more questions about this job, please free to email us at help@local2local.com.au or you can visit <a href="<?php echo e(route('service_seeker_more_help')); ?>" onclick="toggle_animation(true);" class="theme-color font-weight-bolder">help section</a> of this app to message us directly from app. 
      </p>
   </div>
</div>
<?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/jobs/partial/job_overview_partial_cancelled.blade.php ENDPATH**/ ?>