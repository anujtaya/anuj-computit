<div  class="w3-padding  w3-border w3-border-light-grey w3-tiny ">
   <?php if($service_provider_business == null): ?>
   <div class="w3-row">
      <div class="w3-col s4">
         <p style="font-weight: bold;">From:</p>
         <p><?php echo e($service_provider->first); ?> <?php echo e($service_provider->last); ?></p>
         <p>ABN: <?php echo e($abn_formatted); ?></p>
      </div>
      <div class="w3-col s4">
         <p style="font-weight: bold;">To:</p>
         <p><?php echo e($service_seeker->first); ?> <?php echo e($service_seeker->last); ?></p>
      </div>
      <div class="w3-col s4">
         <p style="font-weight: bold;">Invoice Information:</p>
         <p>Invoice Number: #INV-<?php echo e($job->id); ?></p>
         <p>Date -   <?php $phpdate = strtotime( $job->created_at ); $mysqldate = date( 'D d/m/Y', $phpdate );  ?><?php echo e($mysqldate); ?></p>
      </div>
   </div>
   <?php else: ?>
   <div class="w3-row">
      <div class="w3-col s4">
         <p style="font-weight: bold;">From:</p>
         <p>Business Name: <?php echo e($service_provider_business->business_name); ?></p>
         <p>Email: <?php echo e($service_provider_business->business_email); ?></p>
         <p>ABN: <?php echo e($abn_formatted); ?></p>
      </div>
      <div class="w3-col s4">
         <p style="font-weight: bold;">To:</p>
         <p><?php echo e($service_seeker->first); ?> <?php echo e($service_seeker->last); ?></p>
      </div>
      <div class="w3-col s4">
         <p style="font-weight: bold;">Invoice Information:</p>
         <p>Invoice Number: #INV-<?php echo e($job->id); ?></p>
         <p>Date -   <?php $phpdate = strtotime( $job->created_at ); $mysqldate = date( 'D d/m/Y', $phpdate );  ?><?php echo e($mysqldate); ?></p>
      </div>
   </div>
   <?php endif; ?>
</div>
<div  class=" w3-border w3-padding w3-border-light-grey w3-tiny ">
   <p><strong>Invoice Items</strong></p>
   <div  class=" w3-margin-top    w3-tiny">
      <div class="w3-row">
         <table class="table table-bordered w3-margin-bottom" style="align:right;">
            <tr>
               <th >Main Item<small>(s)</small></th>
               <th class="w3-right-align">Item Cost</th>
               <th class="w3-right-align">Item Quantity</th>
               <th class="w3-right-align">Rate</th>
               <th class="w3-right-align">Total</th>
            </tr>
            <tr>
               <td ><?php echo e($job->service_category_name); ?> - <?php echo e($job->service_subcategory_name); ?></td>
               <td class="w3-right-align"><?php echo e(number_format($conversation->json['offer'], 2)); ?></td>
               <td class="w3-right-align">1</td>
               <td class="w3-right-align"><?php echo e(number_format($conversation->json['offer'], 2)); ?></td>
               <td class="w3-right-align">$<?php echo e(number_format($conversation->json['offer'], 2)); ?></td>
            </tr>
            <tr class=" ">
               <td style="border: none;"></td>
               <td style="border: none;"></td>
               <td style="border: none;"></td>
               <td style="border: none;"></td>
               <td style="border: none;"></td>
            </tr>
            <?php if($extras !=null): ?>
            <tr>
               <th >Extras</th>
               <th class="w3-right-align">Notes</th>
               <th class="w3-right-align">Quantity</th>
               <th class="w3-right-align">Rate</th>
               <th class="w3-right-align">Extra(s) Total</th>
            </tr>
            <?php $__currentLoopData = $extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="">
               <td><?php echo e($extra->name); ?></td>
               <td ><?php echo e($extra->description); ?></td>
               <td class="w3-right-align"><?php echo e($extra->quantity); ?></td>
               <td class="w3-right-align"><?php echo e($extra->price); ?></td>
               <td class="w3-right-align">$<?php echo e(number_format((float)$extra->price * $extra->quantity, 2, '.', '')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
               <td>
                  <p>No extras were assigned to this job.</p>
               </td>
            </tr>
            <?php endif; ?>
         </table>
         <table  class="w3-table w3-striped w3-border w3-border-light-grey" style="align:right;">
            <tr class="">
               <td></td>
               <td></td>
               <td class="w3-right-align">
                  <div class="w3-row">
                     <div class="w3-col s6 ">
                        Total Service Charges & Extras:
                     </div>
                     <div class="w3-col s6 font-weight-bolder">
                        $<?php echo e(number_format($job_payment->payable_job_price,2)); ?>

                     </div>
                  </div>
                  <div class="w3-row">
                     <div class="w3-col s6">
                        Credit Card Fee:
                     </div>
                     <div class="w3-col s6">
                        $0.00
                     </div>
                  </div>
                  <div class="w3-row">
                     <div class="w3-col s6">
                        GST included in this invoice:
                     </div>
                     <div class="w3-col s6">
                        $<?php echo e(number_format($job_payment->gst_fee_value,2)); ?>

                     </div>
                  </div>
               </td>
            </tr>
         </table>
      </div>
   </div>
</div><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/invoice/ss_invoice_extension.blade.php ENDPATH**/ ?>