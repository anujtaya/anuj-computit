<?php $__env->startSection('content'); ?>
<style>
   body,html {
   }
   .modal-backdrop {
   position: fixed;
   top: 0;
   right: 0;
   bottom: 0;
   left: 0;
   z-index: 1040;
   background-color: #000!important;
   }
   .modal-backdrop.in {
   filter: alpha(opacity=50);
   }
</style>
<div class="container  text-white   mt-0 p-0">
   <div class="row  justify-content-center" >
      <div class="col-lg-4    col-md-12 p-0" style="">
         <div class="p-4  theme-color rounded  m-4" style="border-radisus:55px; margin-top: 0px;">
            <div class="mb-4 text-dark fs-1">Reset Password</div>
            <?php if(session('status')): ?>
            <div class="alert alert-success fs--1" role="alert">
               <?php echo e(session('status')); ?> 
            </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('password.email')); ?>" onsubmit="toggle_animation(true);">
               <?php echo csrf_field(); ?>
               <div class="form-group">
                  <label for="email" class=""><?php echo e(__('E-Mail Address')); ?></label>
                  <div class="">
                     <input id="email" type="email" class="form-control form-control-sm <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                     <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                     <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                     </span>
                     <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </div>
               </div>
               <div class="form-group row mb-0">
                  <button type="submit" class="btn  btn-success btn-sm fs--1 text-white ml-3 card-1 mb-1">
                  <i class="fas fa-paper-plane"></i> <?php echo e(__('Send Password Reset Link')); ?>

                  </button>
               </div>
               <a href="<?php echo e(route('login')); ?>" class="btn  btn-success btn-sm fs--1 text-white card-1 mt-3   mb-1">
               <i class="fas fa-lock"></i> <?php echo e(__('Login')); ?>

               </a>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>