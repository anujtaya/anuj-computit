<?php $__env->startSection('content'); ?>
<div class="container mt-2">
   <div class="row  justify-content-center" >
      <div class="col-lg-4  ">
         <div class="row   " >
            <div class="col-md-12 h-100  " >
               <div class="card bg-white p-3 shadow-none">
                  <div class="d-flex bd-highlight mb-1">
                     <div class="p-1 theme-color bd-highlight">  
                        <span class="fs--">Step 3 of 4</span> 
                     </div>
                     <div class="p-1 ml-auto bd-highlight">
                        <a href="<?php echo e(route('service_provider_register_langauges')); ?>"  class="font-weight-bolder theme-color" onclick="toggle_animation(true);"> Next</a>
                     </div>
                  </div>
                  <?php echo $__env->make('service_provider.certificate.add_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <div class=" mb-2 text-centers">
                        <h1 class="fs-1">Your Certificates</h1>
                     </div>
                  <ul class="list-group fs--1">
                     <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li class="list-group-item">               
                        <div class="d-flex bd-highlight">
                           <div class="p-1 flex-grow-1 bd-highlight"> <?php echo e($certificate->certificate_name); ?></div>
                           <div class="p-1 bd-highlight"><?php echo e(date('d/m/Y', strtotime($certificate->certificate_expiry))); ?></div>
                           <div class="p-1 bd-highlight"> <a href="<?php echo e(route('service_provider_delete_certificate', $certificate->id)); ?>" onclick="toggle_animation(true);" class="text-decoration-none text-danger">Remove</a> </div>
                        </div>      
                     </li>   
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>         
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<div class="progress fixed-top rounded-0" style="height: 10px;">
  <div class="progress-bar  theme-background-color" role="progressbar" style="width:35%;" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<script>
    $(".progress-bar").animate({
    width: "80%"
}, 100);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.service_provider_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/certificate/registration_page.blade.php ENDPATH**/ ?>