<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('/car_map_demo.js')); ?>?v=<?php echo e(rand(1,100)); ?>"></script>
<style></style>
<div class="container fs--1">
   <div class="form-group">
      <label for="exampleInputEmail1">Start Address</label>
      <input type="text" class="form-control" id="start_address" aria-describedby="emailHelp" value="">
   </div>
   <div class="form-group">
      <label for="exampleInputEmail1">End Address</label>
      <input type="text" class="form-control" id="end_address">
   </div>
   <button onclick="animate_marker();" class="btn btn-primary text-white">Submit</button>
   <!-- map div -->
   <div id="map" class="text-center " style="min-width:900px important; min-height:440px!important; position: relative;overflow: hidden;"></div>
   <!-- end map div  -->
</div>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyClfjwR-ajvv7LrNOgMRe4tOHZXmcjFjaU&libraries=places&callback=initMap" async defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/demo/car_map_demo.blade.php ENDPATH**/ ?>