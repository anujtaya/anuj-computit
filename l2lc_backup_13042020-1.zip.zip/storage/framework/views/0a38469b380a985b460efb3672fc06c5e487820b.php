<?php $__env->startSection('content'); ?>
<?php $__env->startPush('header-style'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header-script'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<?php $__env->stopPush(); ?>
<div class="container ">
   <div class="row  justify-content-center" >
      <div class="col-lg-12 shadow-sm sticky-top bg-white p-3 border-d">
         <div class="row">
            <div class="col-2">
               <a href="<?php echo e(route('service_provider_profile_nested')); ?>" onclick="toggle_animation(true);"><i class="fas fa-arrow-left theme-color fs-1" ></i> </a>
            </div>
            <div class="col-8 font-size-bolder text-center font-weight-bold theme-color">
               Add Languages
            </div>
            <div class="col-2 text-right">
            </div>
         </div>
      </div>
      <div class="col-lg-12 p-3">
         <div class="p-1">
            <?php echo $__env->make('service_provider.language.add_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class=" mb-2 text-centers">
               <h1 class="fs--1">Saved Languages</h1>
            </div>
            <ul class="list-group fs--1">
               <?php $__currentLoopData = $current_languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li class="list-group-item">               
                  <div class="d-flex bd-highlight">
                     <div class="p-1 flex-grow-1 bd-highlight"> <?php echo e($language->language_name); ?></div>
                     <div class="p-1 bd-highlight"> <a href="<?php echo e(route('service_provider_delete_language', $language->id)); ?>" onclick="toggle_animation(true);" class="text-decoration-none text-danger">Remove</a> </div>
                  </div>      
               </li>   
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>         
         </div>
      </div>
   </div>
</div>

<script>

$(document).ready(function() { $("#language-select").select2(); });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.service_provider_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/profile/nested/add_languages_partial.blade.php ENDPATH**/ ?>