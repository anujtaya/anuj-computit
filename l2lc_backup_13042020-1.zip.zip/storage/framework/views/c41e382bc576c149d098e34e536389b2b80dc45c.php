<?php $__env->startSection('content'); ?>
<div class="container ">
   <div class="row  justify-content-center" >
      <div class="col-lg-12 shadow-sm sticky-top bg-white p-3 border-d">
         <div class="row">
            <div class="col-2"><a href="<?php echo e(URL::previous()); ?>" onclick="toggle_animation(true);"><i class="fas fa-arrow-left fs-1" style="color:#399BDB!important"></i> </a> </div>
            <div class="col-8 font-size-bolder text-center font-weight-bold theme-color"><?php echo e($user->first); ?> <?php echo e($user->last); ?><br><span class="fs--2 text-muted font-weight-normal"> Service Provider Profile</span></div>
            <div class="col-2 text-right">
            </div>
         </div>
      </div>
      <div class="col-lg-12 mt-2 p-0" > 
         <?php echo $__env->make('service_seeker.jobs.partial.job_service_provider_profile_partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.service_seeker_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/jobs/partial/job_service_provider_profile.blade.php ENDPATH**/ ?>