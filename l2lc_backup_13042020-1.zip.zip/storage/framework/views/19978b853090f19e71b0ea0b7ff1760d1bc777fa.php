<form method="POST" action="<?php echo e(route('service_provider_register_certificate_process')); ?>" onsubmit="toggle_animation(true);">
   <?php echo csrf_field(); ?>
   <div class="form-group  mt-3 row">
      <div class="col-md-12 mb-2 text-centers">
      <h1 class="fs-1">Add Your Certificates</h1>
      </div>
      <div class="col-md-12 mb-3">
         <label for="name">Name</label>
         <input id="name" type="text" class="form-control form-control-sm  <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name"  autofocus>
         <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="date">Expiry</label>
         <input id="date" type="date" class="form-control  form-control-sm <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="date" value="<?php echo e(old('date')); ?>" required autocomplete="date"  autofocus>
         <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-4">
         <label for="guid">Unique ID</label>
         <input id="guid" type="text" class="form-control form-control-sm  <?php if ($errors->has('guid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guid'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="guid" value="<?php echo e(old('guid')); ?>" required autocomplete="guid"  autofocus>
         <?php if ($errors->has('guid')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guid'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 text-centers mb-0">
         <button type="submit" class="btn theme-background-color shadow-sm fs--1 font-weight-normal mt-0" width="221px" height="47px" id="" >
         <i class="fas fa-arrow-up"></i>  <?php echo e(__('Upload')); ?>

         </button>
      </div>
   </div>
</form><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/certificate/add_form.blade.php ENDPATH**/ ?>