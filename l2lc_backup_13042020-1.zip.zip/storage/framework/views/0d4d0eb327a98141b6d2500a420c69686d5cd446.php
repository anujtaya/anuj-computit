<?php $__env->startSection('content'); ?>
<?php $__env->startPush('header-script'); ?>
<script src="<?php echo e(asset('/js/service_seeker/service_seeker_home.js')); ?>?v=<?php echo e(rand(1,100)); ?>"></script>
<script src="<?php echo e(asset('/js/service_seeker/service_seeker_home_map.js')); ?>?v=<?php echo e(rand(1,100)); ?>"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/css/third/flatpickr.min.css')); ?>">
<script src="<?php echo e(asset('/js/third/flatpickr.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<div class="container ">
   <div class="row  justify-content-center" >
      <div class="col-lg-4 p-0 border-d"  id="view_box_1"   >
           <?php echo $__env->make('service_seeker.main_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <div class="col-lg-4 p-0 border-d"  id="view_box_2" style="display:none;">
           <?php echo $__env->make('service_seeker.service_wizard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
   </div>
</div>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyClfjwR-ajvv7LrNOgMRe4tOHZXmcjFjaU&libraries=places&callback=initMap" async defer></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.service_seeker_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/service_seeker_home_1.blade.php ENDPATH**/ ?>