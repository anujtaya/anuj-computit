<?php $__env->startComponent('mail::message' ); ?>
Dear LocaL2LocaL Admin,
<p>A help request is made by <b><?php echo e($user->first); ?> <?php echo e($user->last); ?></b> (username: <?php echo e($user->email); ?>). The content of the help request are described below.</p>
<p>
   <b>Support Type:</b>
   <br>
   <?php echo e($user->support_type); ?>

   <br> <br>
   <b>Support Message:</b>
   <br> 
   <?php echo e($user->support_message); ?>

</p>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/mail/support/support_email.blade.php ENDPATH**/ ?>