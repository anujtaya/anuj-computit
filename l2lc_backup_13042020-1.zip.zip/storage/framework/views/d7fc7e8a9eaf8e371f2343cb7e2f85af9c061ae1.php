<form method="POST" action="<?php echo e(route('login')); ?>" id="login_form" onsubmit="toggle_animation(true);">
   <?php echo csrf_field(); ?>
   <div class="form-group row">
      <div class="col-md-12 p-3">
         <label for="email">Email</label>
         <input id="email" type="email" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control text " style="border-radiuss:20px!important;" name="email" value="<?php echo e(old('email')); ?>" required  placeholder="Email" >
         <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 p-3">
         <label for="password">Password</label>
         <input id="password" type="password" class="<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> form-control text " style="border-radiuss:20px!important;" name="password" required placeholder="Password" >
         <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 text-left p-3">
         <button class="btn  btn-success fs--1 text-white" styles="border-top-left-radius:20px;border-bottom-left-radius:20px;padding-left:10px;padding-top:15px;padding-bottom:15px;"><i class="fas fa-lock"></i> Login </button>
         <br><br>
         <a href="<?php echo e(route('password.request')); ?>" class="text-decoration-none text-dark  ml-1" onclick="toggle_animation(true);"> Forgot Password</a> |
         <a class="text-dark" style="cursor:pointer" data-toggle="modal" data-target="#exampleModalCenter">
         Sign up
         </a>
      </div>
      </span>
   </div>
</form><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/auth/forms/login-form.blade.php ENDPATH**/ ?>