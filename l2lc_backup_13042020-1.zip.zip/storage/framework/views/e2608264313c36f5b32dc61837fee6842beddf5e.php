<style>
.switch {
  display: inline-block;
  height: 28px!important;
  position: relative;
  width: 55px!important;
}

.switch input {
  display:none;
}

.slider {
  background-color: #ccc;
  bottom: 0;
  cursor: pointer;
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  transition: .4s;
}

.slider:before {
  background-color: #fff;
  bottom: 4px;
  content: "";
  height: 20px;
  left: 4px;
  position: absolute;
  transition: .4s;
  width: 20px;
}

input:checked + .slider {
  background-color: #5d29ba7a!important;
}

input:checked + .slider:before {
  transform: translateX(26px);
}

.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>

<form method="POST" action="<?php echo e(route('service_provider_register_business_process')); ?>" onsubmit="toggle_animation(true);">
   <?php echo csrf_field(); ?>
   <div class="form-group  mt-3 row">
      <div class="col-md-12 mb-4 text-centers">
         <h1 class="fs-1">Provide Your Business Information</h1>
      </div>
      <div class="col-md-12 mb-3">
         <label for="business_name">Business Name</label>
         <input id="business_name" type="text" class="form-control form-control-sm  <?php if ($errors->has('business_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="business_name" value="<?php echo e(old('business_name')); ?>" required autocomplete="business_name"  autofocus>
         <?php if ($errors->has('business_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_name'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="business_email">Business Email</label>
         <input id="business_email" type="email" class="form-control  form-control-sm <?php if ($errors->has('business_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="business_email" value="<?php echo e(old('business_email')); ?>" required autocomplete="business_email"  autofocus>
         <?php if ($errors->has('business_email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_email'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-4">
         <label for="business_address">Business Address</label>
         <input id="business_address" type="text" class="form-control   form-control-sm <?php if ($errors->has('business_address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Optional" name="business_address" value="<?php echo e(old('business_address')); ?>" autocomplete="business_address"  autofocus>
         <?php if ($errors->has('business_address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_address'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-4">
         <label for="business_abn">Business ABN</label>
         <input id="business_abn" type="number" class="form-control   form-control-sm <?php if ($errors->has('business_abn')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_abn'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Optional" name="business_abn" value="<?php echo e(old('business_abn')); ?>"  autocomplete="business_abn">
         <?php if ($errors->has('business_abn')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_abn'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-2">
         <label for="business_gst">Are you registered for GST?</label>
         <br>
         <label class="switch" for="checkbox">
            <input type="checkbox" id="checkbox" name="business_gst" >
            <div class="slider round"></div>
         </label>
      </div>
      <div class="col-md-12 text-centers mb-0">
         <button type="submit" class="btn theme-background-color fs--1 shadow-sm  font-weight-normal mt-2" width="221px" height="47px" id="" >
         <?php echo e(__('Continue')); ?> <i class="fas fa-arrow-right"></i>
         </button>
      </div>
   </div>
</form><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_provider/business/add_form.blade.php ENDPATH**/ ?>