<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\l2lc\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>