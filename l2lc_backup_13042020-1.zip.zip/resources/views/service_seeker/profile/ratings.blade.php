<div class="m-2">
   <div class="d-flex bd-highlight rounded m-2 shadow-sm">
      <div class="p-3 bd-highlight">
         Your Service Seeker Rating <br>
         <span class="fs-2">5.0</span> <br>
      </div>
      <div class="ml-auto p-2 bd-highlight">
         <span class="text-warning"><i class="fas fa-star mt-2"></i> <i class="fas fa-star mt-2"></i> <i class="fas fa-star mt-2"></i>  <i class="fas fa-star-half-alt"></i> </span>
      </div>
   </div>
   <div class="p-2 fs--2">Your rating is calculated based on your last 500 completed jobs.</div>
</div>