<div class="pl-3 pr-3">
    <p>
        As a Service Provider you may be eligible to recieve a cancellation fee 
        if a Service Seeker cancel a job booking after 10 minutes of accepting the job offer. 
        This applies to all services offered at LocaL2LocaL platform. 
    </p>
    <p>
        If for some reason you are not able to do a a job, 
        please press the cancel button below and the Service Seeker won't be charged a cancellation fee.
    </p>
    <p>
        If you have more questions about this job, please free to email us at help@local2local.com.au or you can visit <span onclick="$('#user_no_account_message_modal').modal('show');" class="theme-color font-weight-bolder">help section</span> of this app to message us directly from app. 
    </p>
</div>