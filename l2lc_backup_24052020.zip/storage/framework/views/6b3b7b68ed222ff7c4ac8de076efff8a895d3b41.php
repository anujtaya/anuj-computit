<form method="POST" action="<?php echo e(route('guest_register_user')); ?>" onsubmit="toggle_animation(true);">
   <?php echo csrf_field(); ?>
   <div class="form-group mt-3 row">
      <div class="col-md-12 mb-2 text-canter">
         <h1 class="fs-1">Start Connecting with your Locals</h1>
      </div>
      <div class="col-md-12 mb-3">
         <label for="first">First Name</label>
         <input id="first" type="text" class="form-control form-control-sm  <?php if ($errors->has('first')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="first" value="Anuj" required autocomplete="first" placeholder="" autofocus>
         <?php if ($errors->has('first')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="last">Last Name</label>
         <input id="last" type="text" class="form-control form-control-sm  <?php if ($errors->has('last')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="last" value="Taya" required autocomplete="last" placeholder="" autofocus>
         <?php if ($errors->has('last')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="email">Email</label>
         <input id="email" type="email" class="form-control form-control-sm  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="john<?php echo e(rand(20,50)); ?>doe@gmail.com" required autocomplete="email" placeholder="" autofocus>
         <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="phone">Mobile No.</label>
         <div class="input-group mb-3">
            <div class="input-group-prepend ">
               <span class="input-group-text fs--1 form-control-sm text-muted" style="padding:0.86rem 1rem!important;" id="basic-addon1">+61</span>
            </div>
            <input id="phone" type="tel" class="form-control  form-control-sm <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" style="border-top-left-radius:0px!important;border-bottom-left-radius:0px!important;" name="phone" value="0452610116" required autocomplete="phone" placeholder="" autofocus>
         </div>
         <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="password">Password</label>
         <input id="password" type="password" class="form-control  form-control-sm <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" value="12346578" required autocomplete="password" placeholder="" autofocus>
         <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
         <span class="invalid-feedback" role="alert">
         <strong><?php echo e($message); ?></strong>
         </span>
         <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
      </div>
      <div class="col-md-12 mb-3">
         <label for="password_confirmation">Confirm Password</label>
         <input id="password_confirmation" type="password" class="form-control form-control-sm <?php if ($errors->has('password_confirmation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password_confirmation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password_confirmation" value="12346578" required autocomplete="password" placeholder="" autofocus>
      </div>
      <div class="col-md-12 text-centerw mb-0">
         <p class="text-centerw fs--1">By signing up, I agree to Local2local Terms and Conditions</p>
         <button type="submit" class="btn  theme-background-color fs--1 text-white  font-weight-normal mt-2" width="221px" height="47px" id="" onclick='main_btn_status(this.id);$("#login_form").submit();'>
         <?php echo e(__('Continue')); ?>

         </button>
         <a  class="btn btn-secondary fs--1 text-white font-weight-normal mt-2" width="221px" height="47px" href="<?php echo e(route('login')); ?>" onclick="toggle_animation(true);"> Cancel</a>
      </div>
   </div>
</form><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/auth/forms/register_form_dev.blade.php ENDPATH**/ ?>