<?php $__env->startComponent('mail::message'); ?>

<?php if(! empty($greeting)): ?>
# <?php echo e($greeting); ?>

<?php else: ?>
<?php if($level === 'error'): ?>
# <?php echo app('translator')->getFromJson('Whoops!'); ?>
<?php else: ?>
# <?php echo app('translator')->getFromJson('Hello there!'); ?>
<?php endif; ?>
<?php endif; ?>

<?php $__currentLoopData = $introLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($line); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<p>
   Welcome to the LocaL2LocaL Community. Thank you for taking the time to update your profile and verify your account. You can now start making service requests.
</p>
<?php $__env->startComponent('mail::button', ['url' => $url1]); ?>
Watch intro video
<?php echo $__env->renderComponent(); ?>
<p>
   Please take a moment to watch these additional videos to learn more about LocaL2LocaL.
</p>
<?php $__env->startComponent('mail::button', ['url' =>$url2]); ?>
Watch additional videos
<?php echo $__env->renderComponent(); ?>
We look forward to a future where you can earn extra money in your spare time or find a local to assist immediately when you require any service.

<?php if(! empty($salutation)): ?>
<?php echo e($salutation); ?>

<?php else: ?>
<?php echo app('translator')->getFromJson('Regards'); ?>,<br>LocaL2LocaL Team
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/mail/account/service_seeker_account_created.blade.php ENDPATH**/ ?>