<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\l2lc\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>