<div class="p-0">
    <?php if($job->status != 'COMPLETED'): ?>
        <?php if($job->status != 'CANCELLED'): ?>
            <p>
                If you would like to cancel this job. You can do so by clicking 'Cancel Job' button.
                A $10.00 cancellation fee may apply if a job is cancelled after being approved.
                This action cannot be undone.
            </p>
            <p>
                If you have more questions about this job, please free to email us at help@local2local.com.au or you can visit <a href="<?php echo e(route('service_seeker_more_help')); ?>" onclick="toggle_animation(true);" class="theme-color font-weight-bolder">help section</a> of this app to message us directly from app. 
            </p>
            <!-- <form action="<?php echo e(route('service_seeker_job_cancel')); ?>" method="POST" onclick="toggle_animation(true);">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="ss_job_cancel_id" value="<?php echo e($job->id); ?>" required>
                <button class="btn btn-danger text-white btn-sm fs--1">Cancel Job</button>
            </form> -->
        <?php endif; ?>
    <?php else: ?> 
    <p>
        If you have more questions about this job, please free to email us at help@local2local.com.au or you can visit <a href="<?php echo e(route('service_seeker_more_help')); ?>" onclick="toggle_animation(true);" class="theme-color font-weight-bolder">help section</a> of this app to message us directly from app. 
    </p>      
    <?php endif; ?>
    
</div><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/jobs/job_help_partial.blade.php ENDPATH**/ ?>