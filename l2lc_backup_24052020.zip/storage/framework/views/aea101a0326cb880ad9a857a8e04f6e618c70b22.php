<?php if($conversation_current != null): ?>
<style>
   .modal-backdrop {
   position:;
   top: 0;
   right: 0;
   bottom: 0;
   left: 0;
   z-index: 0;
   background-color:transparent;
   }
   .fade {
      transition: opacity .15s linear;
   }
</style>
<div class="fs--1">
   <div class="mt-3 border-0  rounded shadow-sm-none" >
      <div class="d-flex bd-highlight">
         <div class="p-q bd-highlight">
            <span class="theme-color" style="font-size: 0.8rem;">Job Total</span>  <br>
            <span class="text-success fs-1"><span class="fs--1">$</span><?php echo e(number_format($job_price,2)); ?></span>
         </div>
         <div class="ml-auto p-0 bd-highlight">
            <a href="<?php echo e(route('service_seeker_job_conversation', [$conversation_current->job_id, $conversation_current->service_provider_id])); ?>"  class="btn theme-background-color btn-sm  card-1 ml-2 fs--1   text-white" onclick="toggle_animation(true);"><i class="fas fa-comments-dollar"></i> Messages</a>
         </div>
      </div>
   </div>
   <div class="p-0 mt-2">
      <ul class="list-group fs--1 border-light border" style="overflow:scroll; height:440px;">
         <?php $__currentLoopData = $job_extras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item mb-1-0  border" style="border-style:dashed!important;">
               <div class="d-flex bd-highlight">
                  <div class="pb-2 w-100 bd-highlight theme-color">
                     <?php echo e($extra->quantity); ?> ×  <?php echo e($extra->name); ?>

                  </div>
                  <div class="pb-2 ml-auto"><span class="fs--2">$</span><?php echo e(number_format(($extra->quantity * $extra->price),2)); ?></div>
               </div>
               <div class="d-flex bd-highlight fs--2">
                  <div class="pb-2 bd-highlight"><?php echo e($extra->description); ?></div>
               </div>
            </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php if(count($job_extras) == 0): ?>
            <span class="text-warning m-2">No job extras currently assigned to this job.</span>
         <?php endif; ?> 
      </ul>
   </div>
</div>
<script>
   var app_url_job_update_completed ="<?php echo e(route('service_provider_job_update_status_cancelontrip')); ?>";
   var CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
</script>
<?php else: ?>
<div class="fs--1 m-3">
   Something went wrong. Please go back to jobs page to resole this error.
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/service_seeker/jobs/partial/job_overview_partial_started.blade.php ENDPATH**/ ?>