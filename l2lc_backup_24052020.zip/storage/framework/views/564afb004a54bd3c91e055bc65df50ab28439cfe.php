<?php $__env->startSection('title', 'Create a new account'); ?>
<?php $__env->startSection('content'); ?>
<style></style>
<div class="container">
   <div class="row  justify-content-center" >
      <div class="col-lg-4">
         <div class="row" >
            <div class="col-md-12 h-100" >
               <div class="card bg-white p-4 shadow-none">
                  <?php if(app()->isLocal()): ?>
                     <?php echo $__env->make('auth.forms.register_form_dev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php else: ?>
                     <?php echo $__env->make('auth.forms.register_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="progress fixed-top rounded-0" style="height: 10px;">
   <div class="progress-bar  theme-background-color" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<script>
    $(".progress-bar").animate({
    width: "10%"
}, 100);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\l2lc\resources\views/auth/register/register.blade.php ENDPATH**/ ?>